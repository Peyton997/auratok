package app.auratok

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var p: Prefs
    private val gray = 0xFF9A9AA8.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float = 15f, bold: Boolean = false, color: Int = Color.WHITE) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun section(t: String) = tv(t, 17f, true, 0xFFB79CFF.toInt()).apply { setPadding(0, dp(22), 0, dp(4)) }

    private fun sw(t: String, on: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = t; isChecked = on; setTextColor(Color.WHITE)
        setOnCheckedChangeListener { _, c -> onChange(c) }
    }

    private fun seek(max: Int, value: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = value
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) { if (fromUser) onChange(v) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(48))
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0E0E14.toInt()); addView(col) })

        col.addView(tv("AuraTok", 28f, true))
        col.addView(tv("Ayarlar anında kaydedilir. TikTok ekranına dönünce uygulanır.", 13f, false, gray))

        // --- Tema ---
        col.addView(section("Tema"))
        val rg = RadioGroup(this)
        ThemeEngine.THEMES.forEach { (k, name) ->
            rg.addView(RadioButton(this).apply {
                text = name; id = View.generateViewId(); tag = k
                setTextColor(Color.WHITE); isChecked = p.theme == k
            })
        }
        rg.setOnCheckedChangeListener { g, id -> p.theme = g.findViewById<RadioButton>(id).tag as String }
        col.addView(rg)
        col.addView(tv("Özel renk (Özel renk temasında geçerli)", 13f, false, gray))
        col.addView(seek(360, p.hue) { p.hue = it })
        col.addView(tv("Renk tonu şiddeti", 13f, false, gray))
        col.addView(seek(60, p.tint) { p.tint = it })

        // --- Cam efekti ---
        col.addView(section("Cam efekti"))
        col.addView(sw("Üst/alt bar ve pencerelerde cam efekti", p.glass) { p.glass = it })
        col.addView(tv("Bulanıklık", 13f, false, gray))
        col.addView(seek(30, p.blur) { p.blur = it })

        // --- Video ---
        col.addView(section("Video"))
        val speedLabel = tv("Hız: ${ThemeEngine.SPEED_LABELS[p.speed]}")
        col.addView(speedLabel)
        col.addView(seek(ThemeEngine.SPEEDS.size - 1, p.speed) {
            p.speed = it
            speedLabel.text = "Hız: ${ThemeEngine.SPEED_LABELS[it]}"
        })

        // --- Ekran ---
        col.addView(section("Ekran"))
        col.addView(sw("Tam ekran (durum ve gezinme çubuğunu gizle)", p.immersive) { p.immersive = it })

        // --- AuraTok simgesi ---
        col.addView(section("AuraTok simgesi"))
        val status = tv("Seçili: ${IconManager.variants[p.icon]}", 13f, false, gray)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        IconManager.variants.forEach { (k, name) ->
            row.addView(ImageView(this).apply {
                setImageResource(IconManager.iconRes(k))
                layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f).apply { setMargins(dp(4), 0, dp(4), 0) }
                setOnClickListener {
                    IconManager.set(this@SettingsActivity, k)
                    status.text = "Seçili: $name (ana ekran birkaç saniyede yenilenir)"
                }
            })
        }
        col.addView(row)
        col.addView(status)

        // --- TikTok kısayol simgesi ---
        col.addView(section("TikTok simgesi"))
        col.addView(tv("Ana ekrana, yukarıda seçtiğin simgeyle yeni bir kısayol eklenir. Basınca resmi TikTok açılır. Eski TikTok simgesini ana ekrandan kendin kaldırırsın.", 13f, false, gray))
        val nameBox = EditText(this).apply { setText("TikTok"); setTextColor(Color.WHITE) }
        col.addView(nameBox)
        col.addView(Button(this).apply {
            text = "Kısayolu ana ekrana ekle"
            setOnClickListener {
                val label = nameBox.text.toString().ifBlank { "TikTok" }
                Toast.makeText(this@SettingsActivity, IconManager.pinTikTokShortcut(this@SettingsActivity, label, p.icon), Toast.LENGTH_LONG).show()
            }
        })
    }
}
