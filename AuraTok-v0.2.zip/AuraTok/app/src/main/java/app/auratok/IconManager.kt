package app.auratok

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Icon

object IconManager {
    val variants = linkedMapOf("aurora" to "Aurora", "neon" to "Neon", "pastel" to "Pastel", "black" to "Siyah")

    fun iconRes(key: String): Int = when (key) {
        "neon" -> R.mipmap.ic_launcher_neon
        "pastel" -> R.mipmap.ic_launcher_pastel
        "black" -> R.mipmap.ic_launcher_black
        else -> R.mipmap.ic_launcher_aurora
    }

    private fun alias(ctx: Context, key: String) =
        ComponentName(ctx, "app.auratok.Icon" + key.replaceFirstChar { it.uppercase() })

    /** AuraTok'un kendi ana ekran simgesini değiştirir (activity-alias yöntemi). */
    fun set(ctx: Context, key: String) {
        val pm = ctx.packageManager
        pm.setComponentEnabledSetting(alias(ctx, key), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        variants.keys.filter { it != key }.forEach {
            pm.setComponentEnabledSetting(alias(ctx, it), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
        }
        Prefs(ctx).icon = key
    }

    /**
     * Ana ekrana, seçili simgeli bir kısayol ekler. Kısayol resmi TikTok'u açar.
     * TikTok uygulamasına hiçbir müdahale yok; sadece kendi kısayolumuz.
     */
    fun pinTikTokShortcut(ctx: Context, label: String, key: String): String {
        val pm = ctx.packageManager
        val pkg = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
            .firstOrNull { pm.getLaunchIntentForPackage(it) != null }
            ?: return "Resmi TikTok uygulaması telefonda bulunamadı."
        val sm = ctx.getSystemService(ShortcutManager::class.java)
        if (!sm.isRequestPinShortcutSupported) return "Bu ana ekran, kısayol eklemeyi desteklemiyor."

        val launch = pm.getLaunchIntentForPackage(pkg)!!.apply { action = Intent.ACTION_MAIN }
        val bmp = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        ctx.getDrawable(iconRes(key))!!.apply { setBounds(0, 0, 256, 256); draw(Canvas(bmp)) }

        val info = ShortcutInfo.Builder(ctx, "tiktok_$key")
            .setShortLabel(label)
            .setIcon(Icon.createWithBitmap(bmp))
            .setIntent(launch)
            .build()
        sm.requestPinShortcut(info, null)
        return "Ana ekrana ekleme isteği gönderildi. Onay çıkarsa kabul et."
    }
}
