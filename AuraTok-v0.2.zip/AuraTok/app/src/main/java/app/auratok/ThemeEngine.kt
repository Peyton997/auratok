package app.auratok

import android.graphics.Color
import org.json.JSONObject

/**
 * TikTok Web sayfasına enjekte edilen CSS ve JS burada üretilir.
 * NOT: TikTok sınıf adlarını sık değiştirir. [class*='...'] seçicileri başlangıç noktasıdır;
 * gerçek sayfada denenip gerekirse güncellenmelidir.
 */
object ThemeEngine {
    data class Palette(val c1: String, val c2: String)

    val SPEEDS = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)
    val SPEED_LABELS = arrayOf("0.5x", "0.75x", "1x", "1.25x", "1.5x", "2x", "3x")

    val THEMES = linkedMapOf(
        "aurora" to "Aurora",
        "neon" to "Neon",
        "pastel" to "Pastel",
        "amoled" to "AMOLED siyah",
        "custom" to "Özel renk"
    )

    private val PRESETS = mapOf(
        "aurora" to Palette("#7B3FD6", "#FF5FA2"),
        "neon" to Palette("#2EF2C2", "#FF4FD8"),
        "pastel" to Palette("#FFB3D1", "#B5D8FF"),
        "amoled" to Palette("#FFFFFF", "#8A8A98")
    )

    private fun hsv(h: Float): String {
        val c = Color.HSVToColor(floatArrayOf(h, 0.75f, 1f))
        return String.format("#%06X", 0xFFFFFF and c)
    }

    fun palette(p: Prefs): Palette =
        if (p.theme == "custom") Palette(hsv(p.hue.toFloat()), hsv(((p.hue + 50) % 360).toFloat()))
        else PRESETS[p.theme] ?: PRESETS.getValue("aurora")

    fun css(p: Prefs): String {
        val c = palette(p)
        val b = p.blur
        val sb = StringBuilder()
        sb.append(":root{--aura-1:${c.c1};--aura-2:${c.c2}}")
        sb.append("*{accent-color:${c.c1}}::selection{background:${c.c1};color:#fff}")
        if (p.tint > 0) {
            sb.append("body::after{content:'';position:fixed;inset:0;pointer-events:none;z-index:2147483646;")
            sb.append("background:linear-gradient(135deg,${c.c1},${c.c2});mix-blend-mode:soft-light;opacity:${p.tint / 100f}}")
        }
        if (p.glass) {
            val glass = "-webkit-backdrop-filter:blur(${b}px) saturate(1.6)!important;backdrop-filter:blur(${b}px) saturate(1.6)!important;"
            sb.append("header,nav,[class*='Header'],[class*='NavContainer'],[class*='TabMenu'],[class*='BottomNav']{$glass background-color:rgba(10,10,20,.35)!important}")
            sb.append("[role='dialog'],[class*='Modal'],[class*='Drawer'],[class*='Popup']{$glass background-color:rgba(20,20,34,.55)!important;border-radius:20px!important}")
        }
        return sb.toString()
    }

    fun script(p: Prefs): String {
        val css = JSONObject.quote(css(p))
        val speed = SPEEDS[p.speed.coerceIn(0, SPEEDS.size - 1)]
        return """
            (function(){
              var css = $css;
              function apply(){
                var s = document.getElementById('auratok-style');
                if(!s){ s = document.createElement('style'); s.id = 'auratok-style'; (document.head || document.documentElement).appendChild(s); }
                if(s.textContent !== css) s.textContent = css;
                document.querySelectorAll('video').forEach(function(v){ if(v.playbackRate !== $speed) v.playbackRate = $speed; });
              }
              apply();
              if(window.__auratok) clearInterval(window.__auratok);
              window.__auratok = setInterval(apply, 800);
            })();
        """.trimIndent()
    }
}
