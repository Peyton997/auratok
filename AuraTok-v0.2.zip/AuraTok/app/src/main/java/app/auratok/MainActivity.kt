package app.auratok

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var prefs: Prefs
    private lateinit var mobileUa: String
    private var desktopApplied = false

    private val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    // Sayfa içinde kalmasına izin verilen adres türleri. Diğerleri (snssdk://, intent:// ...) engellenir.
    private val allowedSchemes = setOf("http", "https", "about", "data", "blob")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        web = WebView(this)

        val d = resources.displayMetrics.density
        val size = (44 * d).toInt()
        val margin = (12 * d).toInt()
        val gear = TextView(this).apply {
            text = "⚙"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x66000000) }
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
            setOnLongClickListener { web.reload(); true }   // uzun bas: sayfayı yenile
        }
        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(gear, FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.END).apply { setMargins(0, margin, margin, 0) })
        setContentView(root)

        setupWeb()
        web.loadUrl("https://www.tiktok.com/")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        // "wv" işareti bazı giriş sayfalarında sorun çıkarıyor, kaldırıyoruz.
        mobileUa = web.settings.userAgentString.replace("; wv", "")
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        applyMode()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme?.lowercase() ?: return false
                return scheme !in allowedSchemes   // true = engelle, sayfada kal
            }
            override fun onPageFinished(view: WebView?, url: String?) { inject() }
            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) { inject() }
        }
    }

    private fun applyMode() {
        val desktop = prefs.desktop
        web.settings.userAgentString = if (desktop) desktopUa else mobileUa
        web.settings.useWideViewPort = desktop
        web.settings.loadWithOverviewMode = desktop
        desktopApplied = desktop
    }

    private fun inject() = web.evaluateJavascript(ThemeEngine.script(prefs), null)

    @Suppress("DEPRECATION")
    private fun applyImmersive() {
        window.decorView.systemUiVisibility = if (prefs.immersive) {
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        } else View.SYSTEM_UI_FLAG_VISIBLE
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        applyImmersive()
        if (prefs.desktop != desktopApplied) { applyMode(); web.reload() }
        inject()
    }
    override fun onPause() { web.onPause(); super.onPause() }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) applyImmersive() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
