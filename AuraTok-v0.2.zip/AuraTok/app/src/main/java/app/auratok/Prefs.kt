package app.auratok

import android.content.Context

/** Tüm ayarlar burada saklanır. İki ekran da aynı SharedPreferences'ı okur. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("auratok", Context.MODE_PRIVATE)

    var theme: String
        get() = sp.getString("theme", "aurora") ?: "aurora"
        set(v) { sp.edit().putString("theme", v).apply() }
    var hue: Int
        get() = sp.getInt("hue", 280)
        set(v) { sp.edit().putInt("hue", v).apply() }
    var tint: Int
        get() = sp.getInt("tint", 20)
        set(v) { sp.edit().putInt("tint", v).apply() }
    var glass: Boolean
        get() = sp.getBoolean("glass", true)
        set(v) { sp.edit().putBoolean("glass", v).apply() }
    var blur: Int
        get() = sp.getInt("blur", 14)
        set(v) { sp.edit().putInt("blur", v).apply() }
    var immersive: Boolean
        get() = sp.getBoolean("immersive", false)
        set(v) { sp.edit().putBoolean("immersive", v).apply() }
    var speed: Int
        get() = sp.getInt("speed", 2)
        set(v) { sp.edit().putInt("speed", v).apply() }
    var desktop: Boolean
        get() = sp.getBoolean("desktop", false)
        set(v) { sp.edit().putBoolean("desktop", v).apply() }
    var icon: String
        get() = sp.getString("icon", "aurora") ?: "aurora"
        set(v) { sp.edit().putString("icon", v).apply() }
}
