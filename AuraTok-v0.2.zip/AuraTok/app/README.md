# AuraTok v0.1

TikTok Web'i kendi uygulamanın içinde açıp üstüne tema katmanı ekleyen Android uygulaması.
TikTok'un kendi uygulamasına dokunmaz.

## Telefonda APK almak (bilgisayar gerekmez)
1. github.com'da ücretsiz hesap aç, yeni bir depo (repo) oluştur.
2. Bu klasördeki tüm dosyaları depoya yükle (".github" klasörü dahil).
3. Depoda **Actions** sekmesine gir, "Build APK" çalışsın (3-5 dk).
4. Bitince çalışmanın altındaki **AuraTok-debug-apk** dosyasını indir, zip'ten çıkar, kur.

## Android Studio ile
Klasörü "Open" ile aç, Gradle eşitlensin, Run veya Build > Build APK.

## Dosyalar
- ThemeEngine.kt: CSS ve JS üretir (tema, cam efekti, video hızı)
- IconManager.kt: AuraTok simgesi + TikTok kısayol simgesi
- MainActivity.kt: WebView; SettingsActivity.kt: ayarlar
